import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-resizable-column',
  templateUrl: './resizable-column.component.html',
  styleUrls: ['./resizable-column.component.css']
})
export class ResizableColumnComponent {}

