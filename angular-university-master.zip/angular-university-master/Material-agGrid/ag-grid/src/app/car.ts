
export interface Car {
      make: string;
      model: number;
      price: number;
    }