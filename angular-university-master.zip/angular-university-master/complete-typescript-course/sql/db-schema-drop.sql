DROP TABLE "Lessons";

DROP TABLE "Courses";

DROP DATABASE "complete-typescript-course";