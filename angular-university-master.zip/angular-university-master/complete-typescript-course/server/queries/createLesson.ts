


import {LessonModel} from "../model/model";


export function createLesson(props: any) {
    return LessonModel.create(props);
}
