


export function buildPersonData (
    {firstName, lastName}:any, ...address:any[]) {
    return `${firstName} ${lastName} ${address}`;
}


