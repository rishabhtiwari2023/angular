
namespace Logging {

    export function logMessage() {
        console.log('Other features');
    }

}

