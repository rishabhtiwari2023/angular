


import * as _ from 'lodash';

const colors = ["Red", "Green", "Blue"];

const firstColor = _.first(colors);

console.log(firstColor);