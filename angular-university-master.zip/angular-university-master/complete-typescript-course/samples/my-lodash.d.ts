

declare interface FirstFunction {
    (data:any[]) :any;
}


declare interface Lodash {

    first:FirstFunction;
}

