import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txtsec2',
  templateUrl: './txtsec2.component.html',
  styleUrls: ['./txtsec2.component.css']
})
export class Txtsec2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
