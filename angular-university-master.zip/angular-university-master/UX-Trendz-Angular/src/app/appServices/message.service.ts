export class MessageService {

    messageAlert() {
        alert('Thanks for subscribe. We will get in touch with you shortly');
      }
}
