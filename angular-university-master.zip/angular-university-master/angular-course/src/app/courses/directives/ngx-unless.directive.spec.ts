import { NgxUnlessDirective } from './ngx-unless.directive';

describe('NgxUnlessDirective', () => {
  it('should create an instance', () => {
    const directive = new NgxUnlessDirective();
    expect(directive).toBeTruthy();
  });
});
