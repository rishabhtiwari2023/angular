import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-form-demo',
  templateUrl: './template-form-demo.component.html',
  styleUrls: ['./template-form-demo.component.css']
})
export class TemplateFormDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
