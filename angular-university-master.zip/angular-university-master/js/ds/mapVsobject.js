// https://medium.com/front-end-weekly/es6-map-vs-object-what-and-when-b80621932373

// var map = new Map([[1,2],[3,4]]);
// console.log(map instanceof Object);// true
// var obj = new Object();
// console.log(obj instanceof Map); // false

var obj = {}; //Empty object
var obj = {id: 1, name: "Test object"}; 
//2 keys here: id maps to 1, and name maps to "Test object"