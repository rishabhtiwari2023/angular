// Objects
const myObject = {};
myObject.title = 'Example Object';
myObject.value = 5;
console.log(myObject);

// object literal
const myListeralObject = {
title : 'Example Object2',
value : 2
};
console.log(myListeralObject);
// using new operator
let objectNew = new Object();
objectNew.title = 'Example 3';
objectNew.value = 6;
console.log(objectNew);
