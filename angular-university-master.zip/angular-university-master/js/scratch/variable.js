let variable;
// you can assign string in variable
variable = 'A string is assigned';
console.log(variable);

// you can assign number in variable
variable = 10;
console.log(variable);

// you can assign array in variable
let array = [1,2,3];
variable = array;
console.log(variable);
let array1 = [];
variable = array1
console.log(variable);

// you can assign Object in variable
let obj = {a:1,b:2};
variable = obj;
console.log(variable);

// you can assign function in variable
function hello(){
    return 10;
}
variable = hello();
console.log(variable);

// you can assign variable in variable
let variable2 = 'how are you';
variable = variable2;
console.log(variable);
