// creating an empty array and adding values
const myArray = [];
myArray.push(1);
myArray.push(3);
myArray.push(5);
console.log(myArray);
// adding values using an array literal
const myLiteralArray = [1,3,5];
console.log(myLiteralArray);

// using new operator
myArrayNew = new Array(1,3,5);
console.log(myArrayNew);


