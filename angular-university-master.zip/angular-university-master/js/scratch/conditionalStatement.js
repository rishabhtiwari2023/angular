// if statements
const age = 21;
if(age > 18){
    console.log('age is greater than 18')
}
if(age > 40){
    console.log('age is greater than 40')
}else if(age > 18){
    console.log('else if block')
}else{
    console.log('else block')
}
