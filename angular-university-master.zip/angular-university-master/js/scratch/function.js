// function declaration
function myFunction(name) {
    return 'Hello '+ name;
}
let greeting = myFunction('Chaman');
console.log(greeting);

var myFunctionExpress = function (name) {
    return 'Hi '+ name;
}
greeting = myFunctionExpress('Bharti');
console.log(greeting);
